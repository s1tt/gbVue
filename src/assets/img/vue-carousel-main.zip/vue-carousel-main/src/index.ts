import VueCarousel from './vue-carousel.vue';

export default VueCarousel;
