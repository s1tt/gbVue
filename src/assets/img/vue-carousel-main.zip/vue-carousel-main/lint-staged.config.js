module.exports = {
  '*.{js,ts,vue}': 'eslint --fix',
  '*.{css,scss,vue}': 'stylelint --fix',
};
