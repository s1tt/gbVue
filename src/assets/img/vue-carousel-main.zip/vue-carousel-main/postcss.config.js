module.exports = {
  plugins: {
    stylelint: {
      fix: true,
    },
  },
};
